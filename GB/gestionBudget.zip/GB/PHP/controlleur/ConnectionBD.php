
<?php
/**
    Fichier : employe.php
    Auteur : Boris Zoretic 
    Fonctionnalité : Classe de control
					 effectue la connexion à la BD
    Date : 17 avril 2017
 
    Vérification :
    Date                   Nom                       Approuvé
    ========================================================= 
    23 avril 2017        Pietro Primo           	 OUI
    23 avril 2017        Maxime Proulx      	     OUI
    23 avril 2017        Boris Zoretic        	     OUI
 
 
    **/
	$servername = "localhost";
	$username = "root";
	$password = "";
	$dbname = "gestion_budget";

	// Create connection
	$conn = new mysqli($servername, $username, $password, $dbname);

	// Check connection
	if ($conn->connect_error) {
		die("Connection failed: " . $conn->connect_error);
	}
?>